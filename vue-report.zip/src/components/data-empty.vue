<template>
  <div class="v-charts-data-empty">
    暂无数据
  </div>
</template>
<script>
export default {
  data() {
    return {
    }
},
}
</script>

<style lang="scss" scoped>
.v-charts-data-empty {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: rgba(255, 255, 255, .9);
  color: #888;
  font-size: 14px;
}
</style>