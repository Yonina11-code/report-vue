import reports from './index.vue'
const formConfig = [reports]
export default formConfig