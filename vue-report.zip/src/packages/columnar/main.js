import { cloneDeep } from "utils-lite"

// 生成相应配置
export const bar = (columns, rows, settings, extra) => {
  const innerRows = cloneDeep(rows)
}