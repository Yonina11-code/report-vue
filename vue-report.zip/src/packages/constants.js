export const STATIC_PROPS = [
  'initOptions', 'loading', 'dataEmpty',
  'judgeWidth', 'widthChangeDelay'
]
export const DEFAULT_THEME = {
  categoryAxis: {
    axisLine: { show: false },
    axisTick: { show: false },
    splitLine: { show: false }
  },
  valueAxis: {
    axisLine: { show: false }
  },
  line: {
    smooth: true
  },
  grid: {
    containLabel: true,
    left: 10,
    right: 10
  }
}
export const DEFAULT_COLORS = [
  '#19d4ae', '#5ab1ef', '#fa6e86',
  '#ffb980', '#0067a6', '#c4b4e4',
  '#d87a80', '#9cbbff', '#d9d0c7',
  '#87a997', '#d49ea2', '#5b4947',
  '#7ba3a8'
]
export const ECHARTS_SETTINGS = [
  'grid', 'dataZoom', 'visualMap',
  'toolbox', 'title', 'legend',
  'xAxis', 'yAxis', 'radar',
  'tooltip', 'axisPointer', 'brush',
  'geo', 'timeline', 'graphic',
  'series', 'backgroundColor', 'textStyle'
]