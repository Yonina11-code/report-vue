export default {
  series: [
    {
      type: 'pie'
    }
  ],
  title: {

  },
  legend: {
    type: 'scroll'
  },
  width: 400,
  height: 600,
  title: {
    textAlign: 'left',
    x:'center',
    y:'top',
  }
}